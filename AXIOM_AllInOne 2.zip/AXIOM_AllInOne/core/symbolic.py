# core/symbolic.py
# Tiny symbolic knowledge graph.

from __future__ import annotations
from typing import Dict, Any

class SymbolicCore:
    def __init__(self):
        self.kg: Dict[str, Dict[str, Any]] = {}

    def update(self, triples):
        for s, p, o in triples:
            self.kg.setdefault(s, {})[p] = o

    def get(self, subj, pred, default=None):
        return self.kg.get(subj, {}).get(pred, default)
