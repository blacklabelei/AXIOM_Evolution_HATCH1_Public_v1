# core/liquid_nn.py
# Minimal liquid-like neural unit (toy), can be extended.

from __future__ import annotations
import numpy as np

class LiquidNN:
    def __init__(self, input_dim: int = 16, output_dim: int = 8, seed: int = 7):
        self.W = np.random.default_rng(seed).normal(0,1,(output_dim, input_dim))
        self.state = np.zeros(input_dim)

    def step(self, x):
        self.state = 0.9*self.state + 0.1*x
        return np.tanh(self.W @ self.state)
