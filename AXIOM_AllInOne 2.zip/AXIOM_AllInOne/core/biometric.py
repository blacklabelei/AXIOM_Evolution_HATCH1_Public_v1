# core/biometric.py
# Adaptive gate: EEG + HRV -> (mode, score, latency_ms).

from __future__ import annotations
import time, numpy as np
from typing import Dict, Any

class AdaptiveGate:
    __v = (0.6180339887, 0.4142135623)
    __a = 0.23
    __L = (0.25, 0.75)

    def __init__(self, seed: int = 11):
        self._ema = None
        self._rng = np.random.default_rng(seed)

    def _z(self, x, eps=1e-6):
        m = x.mean(axis=-1, keepdims=True)
        s = x.std(axis=-1, keepdims=True)
        return (x - m) / (s + eps)

    def run(self, eeg, hrv, text=None) -> Dict[str, Any]:
        t0 = time.time()
        z = self._z(eeg)
        feat = np.mean(np.abs(z), axis=-1)
        zmag = float(np.mean(np.abs(feat)))
        raw  = zmag * (self.__v[0] + self.__v[1]*(1.0 - float(np.clip(hrv,0,1))))
        self._ema = raw if self._ema is None else self.__a*raw + (1-self.__a)*self._ema
        s = float(self._ema)
        mode = "REDUCE" if s >= self.__L[1] else ("FULL" if s <= self.__L[0] else "FOCUSED")
        return {"mode": mode, "score": round(s,3), "latency_ms": int((time.time()-t0)*1000)}
