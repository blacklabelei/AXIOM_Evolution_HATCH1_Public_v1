ADA Shield placeholder
----------------------
This folder holds your ADA compliance and rights-lock artifacts.
Replace the placeholder lock with your real, signed KAI_OVERRIDE_LOCK file.
