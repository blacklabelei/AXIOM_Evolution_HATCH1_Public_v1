# api/axiom.py
# Public AXIOM system API (single import point)

from __future__ import annotations
import json
from typing import Dict, Any, List, Tuple
import numpy as np
from ..core.memory_lattice import RecursiveMemoryLattice
from ..core.biometric import AdaptiveGate
from ..core.symbolic import SymbolicCore
from ..core.liquid_nn import LiquidNN

class AxiomSystem:
    def __init__(self, embedding_dim: int = 256, eeg_channels: int = 16):
        self.lattice = RecursiveMemoryLattice(embedding_dim)
        self.gate = AdaptiveGate()
        self.symbols = SymbolicCore()
        self.net = LiquidNN(input_dim=eeg_channels, output_dim=8)

    # ---- Memory ops ----
    def insert(self, text: str, meta: Dict[str, Any], parent_id: str | None = None) -> str:
        return self.lattice.add_memory(text, meta, parent_id=parent_id)

    def query(self, text: str, meta: Dict[str, Any], k: int = 5) -> List[Tuple[str,float]]:
        return self.lattice.query(text, meta, k=k)

    # ---- Biometrics ----
    def process_biometrics(self, eeg: np.ndarray, hrv: float, text_hint: str | None = None) -> Dict[str, Any]:
        res = self.gate.run(eeg, hrv, text_hint)
        # drive symbolic state + liquid net (optional downstream policy)
        feat = np.mean(np.abs((eeg - eeg.mean(axis=-1, keepdims=True)) / (eeg.std(axis=-1, keepdims=True)+1e-6)), axis=-1)
        logits = self.net.step(feat)
        self.symbols.update([("session","mode",res["mode"])])
        res["logits_sample"] = [float(x) for x in logits[:3]]
        return res

    # ---- Persistence ----
    def save_state(self, path: str):
        return self.lattice.save(path)

    def load_state(self, path: str):
        return self.lattice.load(path)

    # ---- Overview ----
    def export_overview(self) -> Dict[str, Any]:
        s = self.lattice.export_state()
        s["symbolic_mode"] = self.symbols.get("session","mode","UNKNOWN")
        return s
