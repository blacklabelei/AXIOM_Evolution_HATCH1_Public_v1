# core/memory_lattice.py
# Recursive Memory Lattice (fractal index, entanglement graph implicit via embeddings).

from __future__ import annotations
import time, uuid, numpy as np
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Set
from .quantum_semantics import QuantumSemanticProcessor, QuantumEmbedding

@dataclass
class MemoryNode:
    node_id: str
    content: Any
    semantic_embedding: QuantumEmbedding
    episodic_context: Dict[str, Any]
    children: List[str] = field(default_factory=list)
    parent: Optional[str] = None
    fractal_level: int = 0
    activation_strength: float = 0.0
    last_accessed: float = field(default_factory=time.time)

class RecursiveMemoryLattice:
    def __init__(self, embedding_dim: int = 256):
        from .mirror_loop import MirrorLoop
        self.nodes: Dict[str, MemoryNode] = {}
        self.fractal_index: Dict[int, List[str]] = defaultdict(list)
        self.semantic_clusters: Dict[str, Set[str]] = defaultdict(set)
        self.qproc = QuantumSemanticProcessor(embedding_dim)
        self.mirror = MirrorLoop()

    def add_memory(self, content: Any, context: Dict[str, Any], parent_id: Optional[str] = None) -> str:
        nid = str(uuid.uuid4())
        emb = self.qproc.create_quantum_embedding(str(content), context)
        node = MemoryNode(nid, content, emb, context)
        if parent_id and parent_id in self.nodes:
            node.parent = parent_id
            node.fractal_level = self.nodes[parent_id].fractal_level + 1
            self.nodes[parent_id].children.append(nid)
        self.nodes[nid]=node
        self.fractal_index[node.fractal_level].append(nid)
        self.mirror.create_mirror(nid, emb.amplitude)
        self._update_clusters(nid, emb)
        return nid

    def _update_clusters(self, nid: str, emb: QuantumEmbedding):
        thr = 0.7
        for vid, v in self.nodes.items():
            if vid==nid: continue
            s = self.qproc.similarity(emb, v.semantic_embedding)
            if s>thr:
                key=f"cluster_{hash(tuple(sorted([nid,vid])))%1000}"
                self.semantic_clusters[key].update([nid,vid])
                emb.entangled_with.add(vid)
                v.semantic_embedding.entangled_with.add(nid)

    def query(self, text: str, context: Dict[str, Any], k: int = 5) -> List[Tuple[str,float]]:
        q = self.qproc.create_quantum_embedding(text, context)
        now = time.time(); out=[]
        for nid, n in self.nodes.items():
            s = self.qproc.similarity(q, n.semantic_embedding)
            fb = 1.0 + 0.1*n.fractal_level
            tb = float(np.exp(-(now-n.last_accessed)/3600.0))
            ab = n.activation_strength
            out.append((nid, float(s*fb*(1+tb+ab))))
        out.sort(key=lambda x:x[1], reverse=True)
        for nid, sc in out[:k]:
            self._activate(nid, sc)
        return out[:k]

    def _activate(self, nid: str, strength: float):
        n = self.nodes.get(nid)
        if not n: return
        n.activation_strength = float(min(1.0, n.activation_strength + 0.1*strength))
        n.last_accessed = time.time()
        for rid in list(n.semantic_embedding.entangled_with):
            r = self.nodes.get(rid)
            if r: r.activation_strength = float(min(1.0, r.activation_strength + 0.05*strength))

    def self_heal(self, nid: str) -> bool:
        n = self.nodes.get(nid)
        if not n: return False
        cur = n.semantic_embedding.amplitude
        inc = self.mirror.detect_inconsistency(nid, cur)
        if inc>self.mirror.reconciliation_threshold:
            hist=[s for ts,vid,s in self.mirror.echo_buffer if vid==nid]
            healed=self.mirror.heal_state(nid, cur, hist[-5:])
            n.semantic_embedding.amplitude=healed
            return True
        return False

    def export_state(self) -> Dict[str, Any]:
        return {
            "nodes": len(self.nodes),
            "fractal_levels": (max(self.fractal_index.keys()) if self.fractal_index else 0),
            "semantic_clusters": len(self.semantic_clusters),
            "quantum_entanglements": int(sum(len(n.semantic_embedding.entangled_with) for n in self.nodes.values())),
            "mirror_states": len(self.mirror.state_mirrors),
        }

    def save(self, path: str):
        # minimal persistence (content + context only; embeddings re-derived deterministically from text)
        data = [{"id": nid, "content": n.content, "context": n.episodic_context, "parent": n.parent} for nid,n in self.nodes.items()]
        with open(path, "w") as f:
            json.dump({"version":"axiom.vΩ", "items":data}, f, indent=2)

    def load(self, path: str):
        with open(path) as f:
            blob = json.load(f)
        self.__init__(self.qproc.dim)
        idmap = {}
        # first pass: roots
        for rec in blob["items"]:
            if rec["parent"] is None:
                nid = self.add_memory(rec["content"], rec["context"], parent_id=None)
                idmap[rec["id"]] = nid
        # second pass: children
        for rec in blob["items"]:
            if rec["parent"] is not None:
                pid = idmap.get(rec["parent"])
                nid = self.add_memory(rec["content"], rec["context"], parent_id=pid)
                idmap[rec["id"]] = nid
