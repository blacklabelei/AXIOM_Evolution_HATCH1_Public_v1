# AXIOM — All-In-One (Core + API + Legal + Seeds)

This folder contains a complete, **non-demo** AXIOM stack:
- **core/**: quantum semantics, mirror loop, memory lattice, biometric gate, symbolic core, liquid net
- **api/**: `AxiomSystem` — the single import you need
- **legal/**: placeholders for your ADA shield and override lock (replace with real files)
- **seeds/**: portable brain seed (triggers & manifests)
- **scripts/**: headless runner example
- **LICENSE.txt**: permissive use for evaluation (customize for your needs)

## Quick Start
```bash
# Python 3.10+, numpy required
pip install numpy

# Run headless example (from AXIOM_AllInOne/)
python -m scripts.run_headless
```

## Public API (import from `api/axiom.py`)
```python
from api.axiom import AxiomSystem
sys = AxiomSystem()

# biometrics
bio = sys.process_biometrics(eeg, hrv)

# memory
nid = sys.insert("some text", {"domain":"demo"})
hits = sys.query("some text", {"domain":"demo"}, k=3)

# persistence
sys.save_state("state.json")
sys.load_state("state.json")

# overview
print(sys.export_overview())
```

## Notes
- No heavy dependencies (Qiskit, DisCoPy, NetworkX) — this will run anywhere.
- Embeddings are **deterministically derived** from content so saved state can be compact.
- Replace **legal placeholders** with your actual signed lock/shield files to enable rights mode.
