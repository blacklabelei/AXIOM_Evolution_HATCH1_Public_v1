# core/mirror_loop.py
# Echo-binding mirror loop for self-healing of node embeddings.

from __future__ import annotations
import time, numpy as np
from collections import deque

class MirrorLoop:
    def __init__(self, threshold: float = 0.85, maxlen: int = 2000):
        self.state_mirrors = {}
        self.echo_buffer = deque(maxlen=maxlen)
        self.reconciliation_threshold = threshold

    def create_mirror(self, node_id: str, state):
        st = state.copy()
        self.state_mirrors[node_id] = st
        self.echo_buffer.append((time.time(), node_id, st))

    def detect_inconsistency(self, node_id: str, current_state) -> float:
        if node_id not in self.state_mirrors:
            return 0.0
        ms = self.state_mirrors[node_id]
        denom = (np.linalg.norm(current_state)*np.linalg.norm(ms)+1e-8)
        sim = float(np.dot(current_state, ms)/denom)
        sim = max(min(sim,1.0), -1.0)
        return 1.0 - sim

    def heal_state(self, node_id: str, current_state, historical_states):
        if not historical_states: return current_state
        weights=[]
        for i, hs in enumerate(historical_states):
            age = 0.9**i
            denom=(np.linalg.norm(current_state)*np.linalg.norm(hs)+1e-8)
            cons=float(np.dot(current_state, hs)/denom)
            weights.append(age*max(cons,0.0))
        s=sum(weights)
        if s==0: return current_state
        w = (np.array(weights)/s).reshape(-1,1)
        stack = np.stack(historical_states, axis=0)
        healed = (w*stack).sum(axis=0)
        self.state_mirrors[node_id]=healed.copy()
        return healed
