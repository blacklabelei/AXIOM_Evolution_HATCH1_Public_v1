# scripts/run_headless.py
# Minimal headless runner: loads/creates state, processes a mock biometric frame, inserts a note.

import json, time
import numpy as np
from pathlib import Path
from ..api.axiom import AxiomSystem

def main():
    sys = AxiomSystem()
    state_path = Path("../state.json")
    if state_path.exists():
        sys.load_state(str(state_path))

    # Mock EEG/HRV
    rng = np.random.default_rng(11)
    eeg = rng.normal(0,1,(16,256))
    hrv = 0.55
    bio = sys.process_biometrics(eeg, hrv, text_hint="session kickoff")
    nid = sys.insert("Initialization complete.", {"domain":"system","mode":bio["mode"]})
    hits = sys.query("Initialization", {"domain":"system"}, k=3)

    sys.save_state(str(state_path))

    out = {
        "bio": bio,
        "inserted": nid,
        "top": hits,
        "overview": sys.export_overview()
    }
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
