# core/quantum_semantics.py
# Lightweight quantum-inspired semantic embeddings (no heavy deps).

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Any, Dict, Set

class QuantumState:
    SUPERPOSITION="superposition"; ENTANGLED="entangled"; COLLAPSED="collapsed"; COHERENT="coherent"

@dataclass
class QuantumEmbedding:
    amplitude: np.ndarray
    phase: np.ndarray
    state: str = QuantumState.COHERENT
    entangled_with: Set[str] = None
    coherence_time: float = 1.0

    def __post_init__(self):
        n = np.linalg.norm(self.amplitude) + 1e-9
        self.amplitude = self.amplitude / n
        if self.entangled_with is None:
            self.entangled_with = set()

class QuantumSemanticProcessor:
    def __init__(self, embedding_dim: int = 256, seed: int = 13):
        self.dim = embedding_dim
        self._rng = np.random.default_rng(seed)

    def create_quantum_embedding(self, text: str, context: Dict[str, Any]) -> QuantumEmbedding:
        # Deterministic seed on text for stability
        h = abs(hash(text)) % (2**32)
        rng = np.random.default_rng(h ^ 0xA5A5A5A5)
        amp = np.abs(rng.normal(0, 1, self.dim))
        phase = np.angle(rng.normal(0,1,self.dim) + 1j*rng.normal(0,0.1,self.dim))
        st = QuantumState.SUPERPOSITION if context.get("uncertainty",0)>0.5 else (
             QuantumState.ENTANGLED if len(context.get("related_concepts",[]))>2 else QuantumState.COHERENT)
        return QuantumEmbedding(amplitude=amp, phase=phase, state=st)

    @staticmethod
    def similarity(e1: QuantumEmbedding, e2: QuantumEmbedding) -> float:
        amp = float(np.dot(e1.amplitude, e2.amplitude))
        phase = float(np.mean(np.cos(np.abs(e1.phase - e2.phase))))
        bonus = 0.1 if e1.state==e2.state else (0.05 if (e1.state==QuantumState.ENTANGLED or e2.state==QuantumState.ENTANGLED) else 0.0)
        return amp*0.7 + phase*0.2 + bonus
